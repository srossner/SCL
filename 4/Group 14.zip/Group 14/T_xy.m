function [ t ] = T_xy( x, y )
%Analitical solution for the bounfry value problem of worksheet 4 (1)(2)
    t = sin(pi.* x') * sin ( pi.* y);
end

