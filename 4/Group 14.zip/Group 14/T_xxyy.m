function [ t ] = T_xxyy( x, y )

	t = -2*pi^2 * sin(pi.* x') * sin ( pi.* y);

end

