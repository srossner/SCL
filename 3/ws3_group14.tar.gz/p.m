function [ pt ] = p( t )
%UNTITLED this function is the analytical solution for the third assignment
    pt =  200./( 20 - ( 10 * exp(-7*t) ) );
end

