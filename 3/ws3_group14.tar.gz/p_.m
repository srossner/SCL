function [ pt_ ] = p_( p )
%UNTITLED this function is the ordinary differential equation for the third
%assignment
    pt_ = 7* ( 1 - (p./10)).*p ;
end

