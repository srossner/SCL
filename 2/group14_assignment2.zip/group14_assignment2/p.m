function [ pt ] = p( t )
%UNTITLED this function is the analitical solution fo the second assignment
    pt =  10./( 1+ ( exp(-t) * 9 )) ;
end

