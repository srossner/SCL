function [ pt_ ] = p_( p )
%UNTITLED this function is the ordinary differential equation for the second
%assignment
    pt_ = (1 - (p./10)).*p ;
end

